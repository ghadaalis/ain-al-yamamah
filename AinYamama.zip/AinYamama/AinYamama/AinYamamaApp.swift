//
//  AinYamamaApp.swift
//  AinYamama
//
//  Created by Ghada Alshabanat on 19/06/1447 AH.
//

import SwiftUI

@main
struct AinYamamaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
