//
//  ContentView.swift
//  AinYamama
//
//  Created by Ghada Alshabanat on 19/06/1447 AH.
//


//صح كامله بدون  الapi
//import SwiftUI
//import AVFoundation
//import UIKit
//import PhotosUI   // ✅ عشان PhotosPicker
//
//// ألوان التطبيق
//struct AppColors {
//    static let primary = Color(UIColor(hex: "#2F5D50")) // أخضر
//}
//
//// حالة واجهة التطبيق
//enum AppStep {
//    case home          // شاشة عين اليمامة
//    case camera        // شاشة الكاميرا
//    case review(UIImage) // مراجعة الصورة
//}
//
//// =====================================================
//// MARK: - ContentView (المتحكم في التنقل بين الشاشات)
//// =====================================================
//struct ContentView: View {
//    @State private var step: AppStep = .home
//
//    var body: some View {
//        ZStack {
//            switch step {
//
//            case .home:
//                HomeScreen {
//                    withAnimation(.easeInOut) {
//                        step = .camera
//                    }
//                }
//
//            case .camera:
//                CameraScreen(
//                    onCaptured: { image in
//                        withAnimation(.easeInOut) {
//                            step = .review(image)
//                        }
//                    },
//                    onClose: {
//                        withAnimation(.easeInOut) {
//                            step = .home
//                        }
//                    }
//                )
//
//            case .review(let image):
//                ReviewScreen(
//                    image: image,
//                    onRetake: {
//                        withAnimation(.easeInOut) {
//                            step = .camera
//                        }
//                    },
//                    onDone: {
//                        // لاحقاً: هنا ننتقل لنتيجة الـ API
//                        withAnimation(.easeInOut) {
//                            step = .home
//                        }
//                    }
//                )
//            }
//        }
//    }
//}
//
//// =====================================================
//// MARK: - شاشة البداية (أيقونة عين اليمامة)
//// =====================================================
//
//
//struct HomeScreen: View {
//    var onStart: () -> Void
//
//    var body: some View {
//        ZStack {
//            // خلفية الجراديانت تغطي الشاشة كاملة
//            LinearGradient(
//                gradient: Gradient(colors: [
//                    Color.black,
//                    Color.black.opacity(0.95),
//                    Color(UIColor(hex: "#0D3A2A")),
//                    Color(UIColor(hex: "#145C43")),
//                    Color(UIColor(hex: "#1C6F52")),
//                ]),
//                startPoint: .top,
//                endPoint: .bottom
//            )
//            .ignoresSafeArea()   // 👈 مهم جداً عشان ما تبقى حواف بيضاء
//
//            VStack(spacing: 24) {
//                Spacer()
//
//                // دائرة السيارة (تقدرين تبدلينها بشعار عين اليمامة من الأصول)
//                Image(systemName: "car.fill")
//                    .font(.system(size: 80))
//                    .foregroundColor(.white)
//                    .padding(40)
//                    .background(AppColors.primary)
//                    .clipShape(Circle())
//                    .shadow(radius: 12)
//
//                // زر "ابدأ الفحص"
//                Button(action: onStart) {
//                    Text("ابدأ الفحص")
//                        .font(.title3.bold())
//                        .foregroundColor(.white)
//                        .padding(.horizontal, 48)
//                        .padding(.vertical, 12)
//                        .background(AppColors.primary.opacity(0.95))
//                        .clipShape(Capsule())
//                        .shadow(radius: 8)
//                }
//                .buttonStyle(.plain)
//
//                // 👇 النص اللي كان مو واضح – عدلناه
//                Text("اضغط على شعار عين اليمامة لفتح الكاميرا وفحص لوحة السيارة.")
//                    .font(.footnote)
//                    .multilineTextAlignment(.center)
//                    .foregroundColor(.white.opacity(0.9))  // لون أوضح بكثير
//                    .padding(.horizontal, 32)
//
//                Spacer()
//
//                Text("Ain Al-Yamamah • Plate Scanner")
//                    .font(.caption2)
//                    .foregroundColor(.white.opacity(0.5))
//                    .padding(.bottom, 20)
//            }
//            .frame(maxWidth: .infinity, maxHeight: .infinity) // يخلي الـ VStack تملاً الشاشة
//        }
//    }
//}
//
//// =====================================================
//// MARK: - شاشة مراجعة الصورة
//// =====================================================
//struct ReviewScreen: View {
//    let image: UIImage
//    var onRetake: () -> Void
//    var onDone: () -> Void
//
//    var body: some View {
//        VStack(spacing: 20) {
//            Text("مراجعة الصورة")
//                .font(.title2.bold())
//
//            Image(uiImage: image)
//                .resizable()
//                .scaledToFit()
//                .frame(maxHeight: 340)
//                .clipShape(RoundedRectangle(cornerRadius: 18))
//                .shadow(radius: 8)
//
//            Text("تأكد أن لوحة السيارة واضحة قبل المتابعة.")
//                .font(.subheadline)
//                .foregroundColor(.secondary)
//
//            HStack(spacing: 12) {
//                Button(role: .cancel) {
//                    onRetake()
//                } label: {
//                    Label("إعادة التصوير", systemImage: "arrow.counterclockwise")
//                        .frame(maxWidth: .infinity)
//                }
//                .buttonStyle(.bordered)
//
//                Button {
//                    onDone()
//                } label: {
//                    Label("تم", systemImage: "checkmark.circle")
//                        .frame(maxWidth: .infinity)
//                }
//                .buttonStyle(.borderedProminent)
//                .tint(AppColors.primary)
//            }
//
//            Spacer()
//        }
//        .padding()
//    }
//}
//
//// =====================================================
//// MARK: - الكاميرا
//// =====================================================
//
//// يتحكم في تشغيل الكاميرا والتصوير
//final class CameraController: NSObject, ObservableObject, AVCapturePhotoCaptureDelegate {
//    @Published var auth: AVAuthorizationStatus = .notDetermined
//    @Published var isRunning = false
//    @Published var torchOn = false
//
//    let session = AVCaptureSession()
//    private let output = AVCapturePhotoOutput()
//    private var device: AVCaptureDevice?
//
//    var onPhoto: ((UIImage?) -> Void)?
//
//    override init() {
//        super.init()
//        Task { await checkAndConfigure() }
//    }
//
//    @MainActor
//    func checkAndConfigure() async {
//        auth = AVCaptureDevice.authorizationStatus(for: .video)
//        if auth == .notDetermined {
//            let granted = await AVCaptureDevice.requestAccess(for: .video)
//            auth = granted ? .authorized : .denied
//        }
//        if auth == .authorized {
//            configureSession()
//        }
//    }
//
//    private func configureSession() {
//        session.beginConfiguration()
//        session.sessionPreset = .photo
//
//        guard let cam = AVCaptureDevice.default(.builtInWideAngleCamera,
//                                               for: .video,
//                                               position: .back),
//              let input = try? AVCaptureDeviceInput(device: cam),
//              session.canAddInput(input) else {
//            session.commitConfiguration()
//            return
//        }
//        session.addInput(input)
//        device = cam
//
//        guard session.canAddOutput(output) else {
//            session.commitConfiguration()
//            return
//        }
//        session.addOutput(output)
//        output.isHighResolutionCaptureEnabled = true
//
//        session.commitConfiguration()
//        start()
//    }
//
//    func start() {
//        guard auth == .authorized, !session.isRunning else { return }
//        DispatchQueue.global(qos: .userInitiated).async {
//            self.session.startRunning()
//            DispatchQueue.main.async { self.isRunning = true }
//        }
//    }
//
//    func stop() {
//        guard session.isRunning else { return }
//        session.stopRunning()
//        isRunning = false
//    }
//
//    func setTorch(_ on: Bool) {
//        guard let d = device, d.hasTorch else { return }
//        do {
//            try d.lockForConfiguration()
//            if on {
//                try d.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
//            } else {
//                d.torchMode = .off
//            }
//            d.unlockForConfiguration()
//        } catch {
//            print("Torch error:", error)
//        }
//    }
//
//    private func applyCurrentOrientation() {
//        if let conn = output.connection(with: .video),
//           conn.isVideoOrientationSupported {
//            conn.videoOrientation = .portrait
//        }
//    }
//
//    func capture() {
//        applyCurrentOrientation()
//        var settings = AVCapturePhotoSettings()
//        if output.availablePhotoCodecTypes.contains(.jpeg) {
//            settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
//        }
//        settings.isHighResolutionPhotoEnabled = true
//        settings.flashMode = torchOn ? .on : .off
//        output.capturePhoto(with: settings, delegate: self)
//    }
//
//    // يرجع الصورة بعد التصوير
//    func photoOutput(_ output: AVCapturePhotoOutput,
//                     didFinishProcessingPhoto photo: AVCapturePhoto,
//                     error: Error?) {
//        if let data = photo.fileDataRepresentation(),
//           let img = UIImage(data: data) {
//            onPhoto?(img)
//        } else {
//            onPhoto?(nil)
//        }
//    }
//}
//
//// UIView لعرض الـ preview حق الكاميرا
//final class PreviewView: UIView {
//    override class var layerClass: AnyClass {
//        AVCaptureVideoPreviewLayer.self
//    }
//
//    var videoPreviewLayer: AVCaptureVideoPreviewLayer {
//        return layer as! AVCaptureVideoPreviewLayer
//    }
//}
//
//// SwiftUI wrapper حول PreviewView
//struct CameraPreview: UIViewRepresentable {
//    let session: AVCaptureSession
//
//    func makeUIView(context: Context) -> PreviewView {
//        let view = PreviewView()
//        view.backgroundColor = .black
//        let layer = view.videoPreviewLayer
//        layer.session = session
//        layer.videoGravity = .resizeAspectFill
//        return view
//    }
//
//    func updateUIView(_ uiView: PreviewView, context: Context) {
//        uiView.videoPreviewLayer.frame = uiView.bounds
//    }
//}
//
//// شاشة الكاميرا نفسها
//struct CameraScreen: View {
//    @StateObject private var cam = CameraController()
//    @State private var pickedItem: PhotosPickerItem?
//    @State private var showHelp = false
//
//    var onCaptured: (UIImage) -> Void
//    var onClose: () -> Void
//
//    var body: some View {
//        ZStack {
//            if cam.auth == .authorized {
//                CameraPreview(session: cam.session)
//                    .ignoresSafeArea()
//
//                VStack {
//                    // أعلى الشاشة: زر إغلاق + زر مساعدة
//                    HStack {
//                        Button {
//                            cam.setTorch(false)
//                            cam.stop()
//                            onClose()
//                        } label: {
//                            Image(systemName: "xmark")
//                                .font(.system(size: 18, weight: .bold))
//                                .foregroundColor(.white)
//                                .padding(10)
//                                .background(Color.black.opacity(0.35))
//                                .clipShape(Circle())
//                        }
//                        .padding(.leading, 16)
//                        .padding(.top, 12)
//
//                        Spacer()
//
//                        Button {
//                            showHelp = true
//                        } label: {
//                            Image(systemName: "questionmark.circle.fill")
//                                .font(.system(size: 26))
//                                .foregroundColor(.white)
//                                .padding(10)
//                                .background(Color.black.opacity(0.35))
//                                .clipShape(Circle())
//                        }
//                        .padding(.trailing, 16)
//                        .padding(.top, 12)
//                    }
//
//                    Spacer()
//
//                    // أزرار أسفل الشاشة
//                    HStack(spacing: 36) {
//
//                        // زر الاستديو
//                        PhotosPicker(selection: $pickedItem, matching: .images) {
//                            Image(systemName: "photo.on.rectangle")
//                                .font(.system(size: 26, weight: .medium))
//                                .foregroundColor(.white)
//                                .frame(width: 60, height: 60)
//                                .background(Color.black.opacity(0.35))
//                                .clipShape(Circle())
//                        }
//                        .task(id: pickedItem) {
//                            guard let item = pickedItem else { return }
//                            if let data = try? await item.loadTransferable(type: Data.self),
//                               let img = UIImage(data: data) {
//                                onCaptured(img)
//                            }
//                        }
//
//                        // زر التصوير
//                        Button {
//                            cam.onPhoto = { img in
//                                if let img = img {
//                                    onCaptured(img)
//                                }
//                            }
//                            cam.capture()
//                        } label: {
//                            Circle()
//                                .fill(Color.white.opacity(0.95))
//                                .frame(width: 84, height: 84)
//                                .overlay(
//                                    Circle()
//                                        .stroke(AppColors.primary, lineWidth: 6)
//                                )
//                                .shadow(radius: 6)
//                        }
//
//                        // زر الفلاش
//                        Button {
//                            cam.torchOn.toggle()
//                            cam.setTorch(cam.torchOn)
//                        } label: {
//                            Image(systemName: cam.torchOn ? "bolt.fill" : "bolt.slash")
//                                .font(.system(size: 26, weight: .semibold))
//                                .foregroundColor(.white)
//                                .frame(width: 60, height: 60)
//                                .background(Color.black.opacity(0.35))
//                                .clipShape(Circle())
//                        }
//                    }
//                    .padding(.bottom, 32)
//                }
//
//            } else {
//                // لو ما فيه صلاحية للكاميرا
//                Color.black.ignoresSafeArea()
//                VStack(spacing: 12) {
//                    Image(systemName: "camera.viewfinder")
//                        .font(.system(size: 50))
//                        .foregroundColor(.white)
//
//                    Text("Camera access is required")
//                        .foregroundColor(.white)
//
//                    if cam.auth == .denied {
//                        Button("Open Settings") {
//                            if let url = URL(string: UIApplication.openSettingsURLString) {
//                                UIApplication.shared.open(url)
//                            }
//                        }
//                        .buttonStyle(.borderedProminent)
//                    } else {
//                        Button("Allow Camera") {
//                            Task { await cam.checkAndConfigure() }
//                        }
//                        .buttonStyle(.borderedProminent)
//                    }
//                }
//            }
//        }
//        .sheet(isPresented: $showHelp) {
//            HelpSheet { showHelp = false }
//                .presentationDetents([.medium, .large])
//        }
//        .onAppear {
//            cam.start()
//        }
//        .onDisappear {
//            cam.setTorch(false)
//            cam.stop()
//        }
//    }
//}
//
//// شاشة المساعدة البسيطة
//
//struct HelpSheet: View {
//    var onClose: () -> Void
//
//    var body: some View {
//        ZStack(alignment: .topTrailing) {
//
//            // محتوى المساعدة
//            ScrollView {
//                VStack(alignment: .trailing, spacing: 20) {
//
//                    // عنوان رئيسي
//                    Text("عن عين اليمامة")
//                        .font(.title2.bold())
//                        .multilineTextAlignment(.trailing)
//
//                    Text("يساعدك تطبيق عين اليمامة على فحص لوحات السيارات والتأكد من حالتها بسرعة وسهولة.")
//                        .font(.body)
//                        .multilineTextAlignment(.trailing)
//                        .foregroundColor(.secondary)
//
//                    Divider()
//                        .padding(.vertical, 4)
//
//                    // عنوان فرعي
//                    Text("طريقة الاستخدام")
//                        .font(.headline.bold())
//                        .multilineTextAlignment(.trailing)
//
//                    VStack(alignment: .trailing, spacing: 16) {
//
//                        helpRow(
//                            icon: "camera.fill",
//                            title: "الكاميرا",
//                            description: "وجّه الكاميرا على لوحة السيارة، ثم التقط صورة باستخدام زر التصوير أسفل الشاشة."
//                        )
//
//                        helpRow(
//                            icon: "photo.on.rectangle",
//                            title: "الاستديو",
//                            description: "يمكنك اختيار صورة سابقة من ألبوم الصور باستخدام زر الصور أسفل الشاشة."
//                        )
//
//                        helpRow(
//                            icon: "bolt.fill",
//                            title: "الفلاش",
//                            description: "فعّل الفلاش لتحسين الإضاءة في الأماكن المظلمة عند الحاجة."
//                        )
//
//                        helpRow(
//                            icon: "checkmark.circle.fill",
//                            title: "المتابعة",
//                            description: "بعد التقاط الصورة، راجعها ثم اضغط (تم) للانتقال لخطوة التحقق."
//                        )
//                    }
//
//                }
//                .padding(.top, 32)
//                .padding(.horizontal, 20)
//                .padding(.bottom, 24)
//            }
//
//            // زر X للإغلاق
//            Button(action: onClose) {
//                Image(systemName: "xmark")
//                    .font(.system(size: 14, weight: .bold))
//                    .foregroundColor(.primary)
//                    .padding(8)
//                    .background(.thinMaterial, in: Circle())
//            }
//            .padding(.top, 8)
//            .padding(.trailing, 16)
//        }
//        // عشان كل شيء يصير يمين لليسار
//        .environment(\.layoutDirection, .leftToRight)
//    }
//
//    // صف واحد (أيقونة + عنوان + وصف)
//    @ViewBuilder
//    private func helpRow(icon: String, title: String, description: String) -> some View {
//        HStack(alignment: .top, spacing: 12) {
//
//            VStack(alignment: .trailing, spacing: 4) {
//                Text(title)
//                    .font(.subheadline.bold())
//                    .multilineTextAlignment(.trailing)
//
//                Text(description)
//                    .font(.footnote)
//                    .foregroundColor(.secondary)
//                    .multilineTextAlignment(.trailing)
//            }
//
//            Image(systemName: icon)
//                .font(.title3)
//        }
//        .frame(maxWidth: .infinity, alignment: .trailing)
//    }
//}
//
//// أداة صغيرة للّون من HEX
//private extension UIColor {
//    convenience init(hex: String) {
//        var s = hex.replacingOccurrences(of: "#", with: "")
//        if s.count == 3 {
//            s = s.map { "\($0)\($0)" }.joined()
//        }
//        var v: UInt64 = 0
//        Scanner(string: s).scanHexInt64(&v)
//        self.init(
//            red:   CGFloat((v >> 16) & 0xFF) / 255.0,
//            green: CGFloat((v >> 8)  & 0xFF) / 255.0,
//            blue:  CGFloat(v & 0xFF) / 255.0,
//            alpha: 1.0
//        )
//    }
//}



//صححح
//import SwiftUI
//import AVFoundation
//import UIKit
//import PhotosUI   // ✅ عشان PhotosPicker
//
//// ألوان التطبيق
//struct AppColors {
//    static let primary = Color(UIColor(hex: "#2F5D50")) // أخضر
//}
//
//// حالة واجهة التطبيق
//enum AppStep {
//    case home            // شاشة عين اليمامة
//    case camera          // شاشة الكاميرا
//    case review(UIImage) // مراجعة الصورة
//    case result(String)  // ⭐️ شاشة النتيجة (رسالة نصية مؤقتاً)
//}
//
//// =====================================================
//// MARK: - ContentView (المتحكم في التنقل بين الشاشات)
//// =====================================================
//struct ContentView: View {
//    @State private var step: AppStep = .home
//
//    var body: some View {
//        ZStack {
//            switch step {
//
//            case .home:
//                HomeScreen {
//                    withAnimation(.easeInOut) {
//                        step = .camera
//                    }
//                }
//
//            case .camera:
//                CameraScreen(
//                    onCaptured: { image in
//                        withAnimation(.easeInOut) {
//                            step = .review(image)
//                        }
//                    },
//                    onClose: {
//                        withAnimation(.easeInOut) {
//                            step = .home
//                        }
//                    }
//                )
//
//            case .review(let image):
//                ReviewScreen(
//                    image: image,
//                    onRetake: {
//                        withAnimation(.easeInOut) {
//                            step = .camera
//                        }
//                    },
//                    onDone: {
//                        // ⭐️ حالياً: نتيجة تجريبية ثابتة (مكان الـ API)
//                        let mockMessage = "نتيجة تجريبية: لا توجد بلاغات على هذه اللوحة في نظام عين اليمامة."
//                        withAnimation(.easeInOut) {
//                            step = .result(mockMessage)
//                        }
//                    }
//                )
//
//            case .result(let message):
//                ResultScreen(
//                    message: message,
//                    onBackHome: {
//                        withAnimation(.easeInOut) {
//                            step = .home
//                        }
//                    }
//                )
//            }
//        }
//    }
//}
//
//// =====================================================
//// MARK: - شاشة البداية (أيقونة عين اليمامة)
//// =====================================================
//
//struct HomeScreen: View {
//    var onStart: () -> Void
//
//    var body: some View {
//        ZStack {
//            // خلفية الجراديانت تغطي الشاشة كاملة
//            LinearGradient(
//                gradient: Gradient(colors: [
//                    Color.black,
//                    Color.black.opacity(0.95),
//                    Color(UIColor(hex: "#0D3A2A")),
//                    Color(UIColor(hex: "#145C43")),
//                    Color(UIColor(hex: "#1C6F52")),
//                ]),
//                startPoint: .top,
//                endPoint: .bottom
//            )
//            .ignoresSafeArea()
//
//            VStack(spacing: 24) {
//                Spacer()
//
//                // دائرة السيارة (تقدرين تبدلينها بشعار عين اليمامة من الأصول)
//                Image(systemName: "car.fill")
//                    .font(.system(size: 80))
//                    .foregroundColor(.white)
//                    .padding(40)
//                    .background(AppColors.primary)
//                    .clipShape(Circle())
//                    .shadow(radius: 12)
//
//                // زر "ابدأ الفحص"
//                Button(action: onStart) {
//                    Text("ابدأ الفحص")
//                        .font(.title3.bold())
//                        .foregroundColor(.white)
//                        .padding(.horizontal, 48)
//                        .padding(.vertical, 12)
//                        .background(AppColors.primary.opacity(0.95))
//                        .clipShape(Capsule())
//                        .shadow(radius: 8)
//                }
//                .buttonStyle(.plain)
//
//                Text("اضغط على شعار عين اليمامة لفتح الكاميرا وفحص لوحة السيارة.")
//                    .font(.footnote)
//                    .multilineTextAlignment(.center)
//                    .foregroundColor(.white.opacity(0.9))
//                    .padding(.horizontal, 32)
//
//                Spacer()
//
//                Text("Ain Al-Yamamah • Plate Scanner")
//                    .font(.caption2)
//                    .foregroundColor(.white.opacity(0.5))
//                    .padding(.bottom, 20)
//            }
//            .frame(maxWidth: .infinity, maxHeight: .infinity)
//        }
//    }
//}
//
//// =====================================================
//// MARK: - شاشة مراجعة الصورة
//// =====================================================
//struct ReviewScreen: View {
//    let image: UIImage
//    var onRetake: () -> Void
//    var onDone: () -> Void
//
//    var body: some View {
//        VStack(spacing: 20) {
//            Text("مراجعة الصورة")
//                .font(.title2.bold())
//
//            Image(uiImage: image)
//                .resizable()
//                .scaledToFit()
//                .frame(maxHeight: 340)
//                .clipShape(RoundedRectangle(cornerRadius: 18))
//                .shadow(radius: 8)
//
//            Text("تأكد أن لوحة السيارة واضحة قبل المتابعة.")
//                .font(.subheadline)
//                .foregroundColor(.secondary)
//
//            HStack(spacing: 12) {
//                Button(role: .cancel) {
//                    onRetake()
//                } label: {
//                    Label("إعادة التصوير", systemImage: "arrow.counterclockwise")
//                        .frame(maxWidth: .infinity)
//                }
//                .buttonStyle(.bordered)
//
//                Button {
//                    onDone()
//                } label: {
//                    Label("تم", systemImage: "checkmark.circle")
//                        .frame(maxWidth: .infinity)
//                }
//                .buttonStyle(.borderedProminent)
//                .tint(AppColors.primary)
//            }
//
//            Spacer()
//        }
//        .padding()
//    }
//}
//
//// =====================================================
//// MARK: - شاشة النتيجة (تجريبية الآن)
//// =====================================================
//struct ResultScreen: View {
//    let message: String
//    var onBackHome: () -> Void
//
//    var body: some View {
//        ZStack {
//            Color(.systemBackground).ignoresSafeArea()
//
//            VStack(spacing: 24) {
//                Spacer()
//
//                Image(systemName: "checkmark.shield.fill")
//                    .font(.system(size: 72))
//                    .foregroundColor(.white)
//                    .padding(32)
//                    .background(AppColors.primary)
//                    .clipShape(Circle())
//                    .shadow(radius: 10)
//
//                Text("نتيجة الفحص")
//                    .font(.title2.bold())
//
//                Text(message)
//                    .font(.body)
//                    .multilineTextAlignment(.center)
//                    .foregroundColor(.secondary)
//                    .padding(.horizontal, 32)
//
//                Spacer()
//
//                Button {
//                    onBackHome()
//                } label: {
//                    Text("عودة للصفحة الرئيسية")
//                        .font(.body.bold())
//                        .frame(maxWidth: .infinity)
//                        .padding(.vertical, 12)
//                }
//                .buttonStyle(.borderedProminent)
//                .tint(AppColors.primary)
//                .padding(.horizontal, 24)
//                .padding(.bottom, 24)
//            }
//        }
//    }
//}
//
//// =====================================================
//// MARK: - الكاميرا
//// =====================================================
//
//// يتحكم في تشغيل الكاميرا والتصوير
//final class CameraController: NSObject, ObservableObject, AVCapturePhotoCaptureDelegate {
//    @Published var auth: AVAuthorizationStatus = .notDetermined
//    @Published var isRunning = false
//    @Published var torchOn = false
//
//    let session = AVCaptureSession()
//    private let output = AVCapturePhotoOutput()
//    private var device: AVCaptureDevice?
//
//    var onPhoto: ((UIImage?) -> Void)?
//
//    override init() {
//        super.init()
//        Task { await checkAndConfigure() }
//    }
//
//    @MainActor
//    func checkAndConfigure() async {
//        auth = AVCaptureDevice.authorizationStatus(for: .video)
//        if auth == .notDetermined {
//            let granted = await AVCaptureDevice.requestAccess(for: .video)
//            auth = granted ? .authorized : .denied
//        }
//        if auth == .authorized {
//            configureSession()
//        }
//    }
//
//    private func configureSession() {
//        session.beginConfiguration()
//        session.sessionPreset = .photo
//
//        guard let cam = AVCaptureDevice.default(.builtInWideAngleCamera,
//                                               for: .video,
//                                               position: .back),
//              let input = try? AVCaptureDeviceInput(device: cam),
//              session.canAddInput(input) else {
//            session.commitConfiguration()
//            return
//        }
//        session.addInput(input)
//        device = cam
//
//        guard session.canAddOutput(output) else {
//            session.commitConfiguration()
//            return
//        }
//        session.addOutput(output)
//        output.isHighResolutionCaptureEnabled = true
//
//        session.commitConfiguration()
//        start()
//    }
//
//    func start() {
//        guard auth == .authorized, !session.isRunning else { return }
//        DispatchQueue.global(qos: .userInitiated).async {
//            self.session.startRunning()
//            DispatchQueue.main.async { self.isRunning = true }
//        }
//    }
//
//    func stop() {
//        guard session.isRunning else { return }
//        session.stopRunning()
//        isRunning = false
//    }
//
//    func setTorch(_ on: Bool) {
//        guard let d = device, d.hasTorch else { return }
//        do {
//            try d.lockForConfiguration()
//            if on {
//                try d.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
//            } else {
//                d.torchMode = .off
//            }
//            d.unlockForConfiguration()
//        } catch {
//            print("Torch error:", error)
//        }
//    }
//
//    private func applyCurrentOrientation() {
//        if let conn = output.connection(with: .video),
//           conn.isVideoOrientationSupported {
//            conn.videoOrientation = .portrait
//        }
//    }
//
//    func capture() {
//        applyCurrentOrientation()
//        var settings = AVCapturePhotoSettings()
//        if output.availablePhotoCodecTypes.contains(.jpeg) {
//            settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
//        }
//        settings.isHighResolutionPhotoEnabled = true
//        settings.flashMode = torchOn ? .on : .off
//        output.capturePhoto(with: settings, delegate: self)
//    }
//
//    // يرجع الصورة بعد التصوير
//    func photoOutput(_ output: AVCapturePhotoOutput,
//                     didFinishProcessingPhoto photo: AVCapturePhoto,
//                     error: Error?) {
//        if let data = photo.fileDataRepresentation(),
//           let img = UIImage(data: data) {
//            onPhoto?(img)
//        } else {
//            onPhoto?(nil)
//        }
//    }
//}
//
//// UIView لعرض الـ preview حق الكاميرا
//final class PreviewView: UIView {
//    override class var layerClass: AnyClass {
//        AVCaptureVideoPreviewLayer.self
//    }
//
//    var videoPreviewLayer: AVCaptureVideoPreviewLayer {
//        return layer as! AVCaptureVideoPreviewLayer
//    }
//}
//
//// SwiftUI wrapper حول PreviewView
//struct CameraPreview: UIViewRepresentable {
//    let session: AVCaptureSession
//
//    func makeUIView(context: Context) -> PreviewView {
//        let view = PreviewView()
//        view.backgroundColor = .black
//        let layer = view.videoPreviewLayer
//        layer.session = session
//        layer.videoGravity = .resizeAspectFill
//        return view
//    }
//
//    func updateUIView(_ uiView: PreviewView, context: Context) {
//        uiView.videoPreviewLayer.frame = uiView.bounds
//    }
//}
//
//// شاشة الكاميرا نفسها
//struct CameraScreen: View {
//    @StateObject private var cam = CameraController()
//    @State private var pickedItem: PhotosPickerItem?
//    @State private var showHelp = false
//
//    var onCaptured: (UIImage) -> Void
//    var onClose: () -> Void
//
//    var body: some View {
//        ZStack {
//            if cam.auth == .authorized {
//                CameraPreview(session: cam.session)
//                    .ignoresSafeArea()
//
//                VStack {
//                    // أعلى الشاشة: زر إغلاق + زر مساعدة
//                    HStack {
//                        Button {
//                            cam.setTorch(false)
//                            cam.stop()
//                            onClose()
//                        } label: {
//                            Image(systemName: "xmark")
//                                .font(.system(size: 18, weight: .bold))
//                                .foregroundColor(.white)
//                                .padding(10)
//                                .background(Color.black.opacity(0.35))
//                                .clipShape(Circle())
//                        }
//                        .padding(.leading, 16)
//                        .padding(.top, 12)
//
//                        Spacer()
//
//                        Button {
//                            showHelp = true
//                        } label: {
//                            Image(systemName: "questionmark.circle.fill")
//                                .font(.system(size: 26))
//                                .foregroundColor(.white)
//                                .padding(10)
//                                .background(Color.black.opacity(0.35))
//                                .clipShape(Circle())
//                        }
//                        .padding(.trailing, 16)
//                        .padding(.top, 12)
//                    }
//
//                    Spacer()
//
//                    // أزرار أسفل الشاشة
//                    HStack(spacing: 36) {
//
//                        // زر الاستديو
//                        PhotosPicker(selection: $pickedItem, matching: .images) {
//                            Image(systemName: "photo.on.rectangle")
//                                .font(.system(size: 26, weight: .medium))
//                                .foregroundColor(.white)
//                                .frame(width: 60, height: 60)
//                                .background(Color.black.opacity(0.35))
//                                .clipShape(Circle())
//                        }
//                        .task(id: pickedItem) {
//                            guard let item = pickedItem else { return }
//                            if let data = try? await item.loadTransferable(type: Data.self),
//                               let img = UIImage(data: data) {
//                                onCaptured(img)
//                            }
//                        }
//
//                        // زر التصوير
//                        Button {
//                            cam.onPhoto = { img in
//                                if let img = img {
//                                    onCaptured(img)
//                                }
//                            }
//                            cam.capture()
//                        } label: {
//                            Circle()
//                                .fill(Color.white.opacity(0.95))
//                                .frame(width: 84, height: 84)
//                                .overlay(
//                                    Circle()
//                                        .stroke(AppColors.primary, lineWidth: 6)
//                                )
//                                .shadow(radius: 6)
//                        }
//
//                        // زر الفلاش
//                        Button {
//                            cam.torchOn.toggle()
//                            cam.setTorch(cam.torchOn)
//                        } label: {
//                            Image(systemName: cam.torchOn ? "bolt.fill" : "bolt.slash")
//                                .font(.system(size: 26, weight: .semibold))
//                                .foregroundColor(.white)
//                                .frame(width: 60, height: 60)
//                                .background(Color.black.opacity(0.35))
//                                .clipShape(Circle())
//                        }
//                    }
//                    .padding(.bottom, 32)
//                }
//
//            } else {
//                // لو ما فيه صلاحية للكاميرا
//                Color.black.ignoresSafeArea()
//                VStack(spacing: 12) {
//                    Image(systemName: "camera.viewfinder")
//                        .font(.system(size: 50))
//                        .foregroundColor(.white)
//
//                    Text("Camera access is required")
//                        .foregroundColor(.white)
//
//                    if cam.auth == .denied {
//                        Button("Open Settings") {
//                            if let url = URL(string: UIApplication.openSettingsURLString) {
//                                UIApplication.shared.open(url)
//                            }
//                        }
//                        .buttonStyle(.borderedProminent)
//                    } else {
//                        Button("Allow Camera") {
//                            Task { await cam.checkAndConfigure() }
//                        }
//                        .buttonStyle(.borderedProminent)
//                    }
//                }
//            }
//        }
//        .sheet(isPresented: $showHelp) {
//            HelpSheet { showHelp = false }
//                .presentationDetents([.medium, .large])
//        }
//        .onAppear {
//            cam.start()
//        }
//        .onDisappear {
//            cam.setTorch(false)
//            cam.stop()
//        }
//    }
//}
//
//// شاشة المساعدة
//
//struct HelpSheet: View {
//    var onClose: () -> Void
//
//    var body: some View {
//        ZStack(alignment: .topTrailing) {
//
//            ScrollView {
//                VStack(alignment: .trailing, spacing: 20) {
//
//                    Text("عن عين اليمامة")
//                        .font(.title2.bold())
//                        .multilineTextAlignment(.trailing)
//
//                    Text("يساعدك تطبيق عين اليمامة على فحص لوحات السيارات والتأكد من حالتها بسرعة وسهولة.")
//                        .font(.body)
//                        .multilineTextAlignment(.trailing)
//                        .foregroundColor(.secondary)
//
//                    Divider()
//                        .padding(.vertical, 4)
//
//                    Text("طريقة الاستخدام")
//                        .font(.headline.bold())
//                        .multilineTextAlignment(.trailing)
//
//                    VStack(alignment: .trailing, spacing: 16) {
//
//                        helpRow(
//                            icon: "camera.fill",
//                            title: "الكاميرا",
//                            description: "وجّه الكاميرا على لوحة السيارة، ثم التقط صورة باستخدام زر التصوير أسفل الشاشة."
//                        )
//
//                        helpRow(
//                            icon: "photo.on.rectangle",
//                            title: "الاستديو",
//                            description: "يمكنك اختيار صورة سابقة من ألبوم الصور باستخدام زر الصور أسفل الشاشة."
//                        )
//
//                        helpRow(
//                            icon: "bolt.fill",
//                            title: "الفلاش",
//                            description: "فعّل الفلاش لتحسين الإضاءة في الأماكن المظلمة عند الحاجة."
//                        )
//
//                        helpRow(
//                            icon: "checkmark.circle.fill",
//                            title: "المتابعة",
//                            description: "بعد التقاط الصورة، راجعها ثم اضغط (تم) للانتقال لخطوة التحقق."
//                        )
//                    }
//
//                }
//                .padding(.top, 32)
//                .padding(.horizontal, 20)
//                .padding(.bottom, 24)
//            }
//
//            // زر X للإغلاق
//            Button(action: onClose) {
//                Image(systemName: "xmark")
//                    .font(.system(size: 14, weight: .bold))
//                    .foregroundColor(.primary)
//                    .padding(8)
//                    .background(.thinMaterial, in: Circle())
//            }
//            .padding(.top, 8)
//            .padding(.trailing, 16)
//        }
//        .environment(\.layoutDirection, .leftToRight)
//    }
//
//    @ViewBuilder
//    private func helpRow(icon: String, title: String, description: String) -> some View {
//        HStack(alignment: .top, spacing: 12) {
//
//            VStack(alignment: .trailing, spacing: 4) {
//                Text(title)
//                    .font(.subheadline.bold())
//                    .multilineTextAlignment(.trailing)
//
//                Text(description)
//                    .font(.footnote)
//                    .foregroundColor(.secondary)
//                    .multilineTextAlignment(.trailing)
//            }
//
//            Image(systemName: icon)
//                .font(.title3)
//        }
//        .frame(maxWidth: .infinity, alignment: .trailing)
//    }
//}
//
//// أداة صغيرة للّون من HEX
//private extension UIColor {
//    convenience init(hex: String) {
//        var s = hex.replacingOccurrences(of: "#", with: "")
//        if s.count == 3 {
//            s = s.map { "\($0)\($0)" }.joined()
//        }
//        var v: UInt64 = 0
//        Scanner(string: s).scanHexInt64(&v)
//        self.init(
//            red:   CGFloat((v >> 16) & 0xFF) / 255.0,
//            green: CGFloat((v >> 8)  & 0xFF) / 255.0,
//            blue:  CGFloat(v & 0xFF) / 255.0,
//            alpha: 1.0
//        )
//    }
//}



import SwiftUI
import AVFoundation
import UIKit
import PhotosUI   // ✅ عشان PhotosPicker

// ألوان التطبيق
struct AppColors {
    static let primary = Color(UIColor(hex: "#2F5D50")) // أخضر
}

// حالة واجهة التطبيق
enum AppStep {
    case home            // شاشة عين اليمامة
    case camera          // شاشة الكاميرا
    case review(UIImage) // مراجعة الصورة
    case result(String)  // ⭐️ شاشة النتيجة (رسالة نصية مؤقتاً)
}

// =====================================================
// MARK: - ContentView (المتحكم في التنقل بين الشاشات)
// =====================================================
struct ContentView: View {
    @State private var step: AppStep = .home
    @StateObject private var loc = LocationManager()   // ✅ جديد: مدير الموقع

    var body: some View {
        ZStack {
            switch step {

            case .home:
                HomeScreen {
                    withAnimation(.easeInOut) {
                        step = .camera
                    }
                }

            case .camera:
                CameraScreen(
                    onCaptured: { image in
                        withAnimation(.easeInOut) {
                            step = .review(image)
                        }
                    },
                    onClose: {
                        withAnimation(.easeInOut) {
                            step = .home
                        }
                    }
                )

            case .review(let image):
                ReviewScreen(
                    image: image,
                    onRetake: {
                        withAnimation(.easeInOut) {
                            step = .camera
                        }
                    },
                    onDone: {
                        // ✅ بدل mockMessage: نرسل الصورة + اللوكيشن للـ API
                        let lat = loc.lastLocation?.coordinate.latitude
                        let lng = loc.lastLocation?.coordinate.longitude
                        print("📍 Location:", lat as Any, lng as Any)


                        APIClient.predict(image: image, lat: lat, lng: lng) { result in
                            DispatchQueue.main.async {
                                switch result {
                                case .success(let res):
                                    withAnimation(.easeInOut) {
                                        step = .result(res.message)
                                    }
                                case .failure:
                                    withAnimation(.easeInOut) {
                                        step = .result("تعذر الاتصال بالخدمة. حاول مرة أخرى.")
                                    }
                                }
                            }
                        }
                    }
                )

            case .result(let message):
                ResultScreen(
                    message: message,
                    onBackHome: {
                        withAnimation(.easeInOut) {
                            step = .home
                        }
                    }
                )
            }
        }
        .onAppear {
            // ✅ طلب صلاحية الموقع أول ما يفتح التطبيق
            loc.requestPermission()
        }
    }
}

// =====================================================
// MARK: - شاشة البداية (أيقونة عين اليمامة)
// =====================================================

struct HomeScreen: View {
    var onStart: () -> Void

    var body: some View {
        ZStack {
            // خلفية الجراديانت تغطي الشاشة كاملة
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color.black.opacity(0.95),
                    Color(UIColor(hex: "#0D3A2A")),
                    Color(UIColor(hex: "#145C43")),
                    Color(UIColor(hex: "#1C6F52")),
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 24) {
                Spacer()

                // دائرة السيارة (تقدرين تبدلينها بشعار عين اليمامة من الأصول)
                Image(systemName: "car.fill")
                    .font(.system(size: 80))
                    .foregroundColor(.white)
                    .padding(40)
                    .background(AppColors.primary)
                    .clipShape(Circle())
                    .shadow(radius: 12)

                // زر "ابدأ الفحص"
                Button(action: onStart) {
                    Text("ابدأ الفحص")
                        .font(.title3.bold())
                        .foregroundColor(.white)
                        .padding(.horizontal, 48)
                        .padding(.vertical, 12)
                        .background(AppColors.primary.opacity(0.95))
                        .clipShape(Capsule())
                        .shadow(radius: 8)
                }
                .buttonStyle(.plain)

                Text("اضغط على شعار عين اليمامة لفتح الكاميرا وفحص لوحة السيارة.")
                    .font(.footnote)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white.opacity(0.9))
                    .padding(.horizontal, 32)

                Spacer()

                Text("Ain Al-Yamamah • Plate Scanner")
                    .font(.caption2)
                    .foregroundColor(.white.opacity(0.5))
                    .padding(.bottom, 20)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}

// =====================================================
// MARK: - شاشة مراجعة الصورة
// =====================================================
struct ReviewScreen: View {
    let image: UIImage
    var onRetake: () -> Void
    var onDone: () -> Void

    var body: some View {
        VStack(spacing: 20) {
            Text("مراجعة الصورة")
                .font(.title2.bold())

            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .frame(maxHeight: 340)
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .shadow(radius: 8)

            Text("تأكد أن لوحة السيارة واضحة قبل المتابعة.")
                .font(.subheadline)
                .foregroundColor(.secondary)

            HStack(spacing: 12) {
                Button(role: .cancel) {
                    onRetake()
                } label: {
                    Label("إعادة التصوير", systemImage: "arrow.counterclockwise")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)

                Button {
                    onDone()
                } label: {
                    Label("تم", systemImage: "checkmark.circle")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppColors.primary)
            }

            Spacer()
        }
        .padding()
    }
}

// =====================================================
// MARK: - شاشة النتيجة (تجريبية الآن)
// =====================================================
struct ResultScreen: View {
    let message: String
    var onBackHome: () -> Void

    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()

            VStack(spacing: 24) {
                Spacer()

                Image(systemName: "checkmark.shield.fill")
                    .font(.system(size: 72))
                    .foregroundColor(.white)
                    .padding(32)
                    .background(AppColors.primary)
                    .clipShape(Circle())
                    .shadow(radius: 10)

                Text("نتيجة الفحص")
                    .font(.title2.bold())

                Text(message)
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 32)

                Spacer()

                Button {
                    onBackHome()
                } label: {
                    Text("عودة للصفحة الرئيسية")
                        .font(.body.bold())
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppColors.primary)
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
    }
}

// =====================================================
// MARK: - الكاميرا
// =====================================================

// يتحكم في تشغيل الكاميرا والتصوير
final class CameraController: NSObject, ObservableObject, AVCapturePhotoCaptureDelegate {
    @Published var auth: AVAuthorizationStatus = .notDetermined
    @Published var isRunning = false
    @Published var torchOn = false

    let session = AVCaptureSession()
    private let output = AVCapturePhotoOutput()
    private var device: AVCaptureDevice?

    var onPhoto: ((UIImage?) -> Void)?

    override init() {
        super.init()
        Task { await checkAndConfigure() }
    }

    @MainActor
    func checkAndConfigure() async {
        auth = AVCaptureDevice.authorizationStatus(for: .video)
        if auth == .notDetermined {
            let granted = await AVCaptureDevice.requestAccess(for: .video)
            auth = granted ? .authorized : .denied
        }
        if auth == .authorized {
            configureSession()
        }
    }

    private func configureSession() {
        session.beginConfiguration()
        session.sessionPreset = .photo

        guard let cam = AVCaptureDevice.default(.builtInWideAngleCamera,
                                               for: .video,
                                               position: .back),
              let input = try? AVCaptureDeviceInput(device: cam),
              session.canAddInput(input) else {
            session.commitConfiguration()
            return
        }
        session.addInput(input)
        device = cam

        guard session.canAddOutput(output) else {
            session.commitConfiguration()
            return
        }
        session.addOutput(output)
        output.isHighResolutionCaptureEnabled = true

        session.commitConfiguration()
        start()
    }

    func start() {
        guard auth == .authorized, !session.isRunning else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            self.session.startRunning()
            DispatchQueue.main.async { self.isRunning = true }
        }
    }

    func stop() {
        guard session.isRunning else { return }
        session.stopRunning()
        isRunning = false
    }

    func setTorch(_ on: Bool) {
        guard let d = device, d.hasTorch else { return }
        do {
            try d.lockForConfiguration()
            if on {
                try d.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
            } else {
                d.torchMode = .off
            }
            d.unlockForConfiguration()
        } catch {
            print("Torch error:", error)
        }
    }

    private func applyCurrentOrientation() {
        if let conn = output.connection(with: .video),
           conn.isVideoOrientationSupported {
            conn.videoOrientation = .portrait
        }
    }

    func capture() {
        applyCurrentOrientation()
        var settings = AVCapturePhotoSettings()
        if output.availablePhotoCodecTypes.contains(.jpeg) {
            settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
        }
        settings.isHighResolutionPhotoEnabled = true
        settings.flashMode = torchOn ? .on : .off
        output.capturePhoto(with: settings, delegate: self)
    }

    // يرجع الصورة بعد التصوير
    func photoOutput(_ output: AVCapturePhotoOutput,
                     didFinishProcessingPhoto photo: AVCapturePhoto,
                     error: Error?) {
        if let data = photo.fileDataRepresentation(),
           let img = UIImage(data: data) {
            onPhoto?(img)
        } else {
            onPhoto?(nil)
        }
    }
}

// UIView لعرض الـ preview حق الكاميرا
final class PreviewView: UIView {
    override class var layerClass: AnyClass {
        AVCaptureVideoPreviewLayer.self
    }

    var videoPreviewLayer: AVCaptureVideoPreviewLayer {
        return layer as! AVCaptureVideoPreviewLayer
    }
}

// SwiftUI wrapper حول PreviewView
struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession

    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.backgroundColor = .black
        let layer = view.videoPreviewLayer
        layer.session = session
        layer.videoGravity = .resizeAspectFill
        return view
    }

    func updateUIView(_ uiView: PreviewView, context: Context) {
        uiView.videoPreviewLayer.frame = uiView.bounds
    }
}

// شاشة الكاميرا نفسها
struct CameraScreen: View {
    @StateObject private var cam = CameraController()
    @State private var pickedItem: PhotosPickerItem?
    @State private var showHelp = false

    var onCaptured: (UIImage) -> Void
    var onClose: () -> Void

    var body: some View {
        ZStack {
            if cam.auth == .authorized {
                CameraPreview(session: cam.session)
                    .ignoresSafeArea()

                VStack {
                    // أعلى الشاشة: زر إغلاق + زر مساعدة
                    HStack {
                        Button {
                            cam.setTorch(false)
                            cam.stop()
                            onClose()
                        } label: {
                            Image(systemName: "xmark")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.white)
                                .padding(10)
                                .background(Color.black.opacity(0.35))
                                .clipShape(Circle())
                        }
                        .padding(.leading, 16)
                        .padding(.top, 12)

                        Spacer()

                        Button {
                            showHelp = true
                        } label: {
                            Image(systemName: "questionmark.circle.fill")
                                .font(.system(size: 26))
                                .foregroundColor(.white)
                                .padding(10)
                                .background(Color.black.opacity(0.35))
                                .clipShape(Circle())
                        }
                        .padding(.trailing, 16)
                        .padding(.top, 12)
                    }

                    Spacer()

                    // أزرار أسفل الشاشة
                    HStack(spacing: 36) {

                        // زر الاستديو
                        PhotosPicker(selection: $pickedItem, matching: .images) {
                            Image(systemName: "photo.on.rectangle")
                                .font(.system(size: 26, weight: .medium))
                                .foregroundColor(.white)
                                .frame(width: 60, height: 60)
                                .background(Color.black.opacity(0.35))
                                .clipShape(Circle())
                        }
                        .task(id: pickedItem) {
                            guard let item = pickedItem else { return }
                            if let data = try? await item.loadTransferable(type: Data.self),
                               let img = UIImage(data: data) {
                                onCaptured(img)
                            }
                        }

                        // زر التصوير
                        Button {
                            cam.onPhoto = { img in
                                if let img = img {
                                    onCaptured(img)
                                }
                            }
                            cam.capture()
                        } label: {
                            Circle()
                                .fill(Color.white.opacity(0.95))
                                .frame(width: 84, height: 84)
                                .overlay(
                                    Circle()
                                        .stroke(AppColors.primary, lineWidth: 6)
                                )
                                .shadow(radius: 6)
                        }

                        // زر الفلاش
                        Button {
                            cam.torchOn.toggle()
                            cam.setTorch(cam.torchOn)
                        } label: {
                            Image(systemName: cam.torchOn ? "bolt.fill" : "bolt.slash")
                                .font(.system(size: 26, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 60, height: 60)
                                .background(Color.black.opacity(0.35))
                                .clipShape(Circle())
                        }
                    }
                    .padding(.bottom, 32)
                }

            } else {
                // لو ما فيه صلاحية للكاميرا
                Color.black.ignoresSafeArea()
                VStack(spacing: 12) {
                    Image(systemName: "camera.viewfinder")
                        .font(.system(size: 50))
                        .foregroundColor(.white)

                    Text("Camera access is required")
                        .foregroundColor(.white)

                    if cam.auth == .denied {
                        Button("Open Settings") {
                            if let url = URL(string: UIApplication.openSettingsURLString) {
                                UIApplication.shared.open(url)
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    } else {
                        Button("Allow Camera") {
                            Task { await cam.checkAndConfigure() }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
            }
        }
        .sheet(isPresented: $showHelp) {
            HelpSheet { showHelp = false }
                .presentationDetents([.medium, .large])
        }
        .onAppear {
            cam.start()
        }
        .onDisappear {
            cam.setTorch(false)
            cam.stop()
        }
    }
}

// شاشة المساعدة

struct HelpSheet: View {
    var onClose: () -> Void

    var body: some View {
        ZStack(alignment: .topTrailing) {

            ScrollView {
                VStack(alignment: .trailing, spacing: 20) {

                    Text("عن عين اليمامة")
                        .font(.title2.bold())
                        .multilineTextAlignment(.trailing)

                    Text("يساعدك تطبيق عين اليمامة على فحص لوحات السيارات والتأكد من حالتها بسرعة وسهولة.")
                        .font(.body)
                        .multilineTextAlignment(.trailing)
                        .foregroundColor(.secondary)

                    Divider()
                        .padding(.vertical, 4)

                    Text("طريقة الاستخدام")
                        .font(.headline.bold())
                        .multilineTextAlignment(.trailing)

                    VStack(alignment: .trailing, spacing: 16) {

                        helpRow(
                            icon: "camera.fill",
                            title: "الكاميرا",
                            description: "وجّه الكاميرا على لوحة السيارة، ثم التقط صورة باستخدام زر التصوير أسفل الشاشة."
                        )

                        helpRow(
                            icon: "photo.on.rectangle",
                            title: "الاستديو",
                            description: "يمكنك اختيار صورة سابقة من ألبوم الصور باستخدام زر الصور أسفل الشاشة."
                        )

                        helpRow(
                            icon: "bolt.fill",
                            title: "الفلاش",
                            description: "فعّل الفلاش لتحسين الإضاءة في الأماكن المظلمة عند الحاجة."
                        )

                        helpRow(
                            icon: "checkmark.circle.fill",
                            title: "المتابعة",
                            description: "بعد التقاط الصورة، راجعها ثم اضغط (تم) للانتقال لخطوة التحقق."
                        )
                    }

                }
                .padding(.top, 32)
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
            }

            // زر X للإغلاق
            Button(action: onClose) {
                Image(systemName: "xmark")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.primary)
                    .padding(8)
                    .background(.thinMaterial, in: Circle())
            }
            .padding(.top, 8)
            .padding(.trailing, 16)
        }
        .environment(\.layoutDirection, .leftToRight)
    }

    @ViewBuilder
    private func helpRow(icon: String, title: String, description: String) -> some View {
        HStack(alignment: .top, spacing: 12) {

            VStack(alignment: .trailing, spacing: 4) {
                Text(title)
                    .font(.subheadline.bold())
                    .multilineTextAlignment(.trailing)

                Text(description)
                    .font(.footnote)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.trailing)
            }

            Image(systemName: icon)
                .font(.title3)
        }
        .frame(maxWidth: .infinity, alignment: .trailing)
    }
}

// أداة صغيرة للّون من HEX
private extension UIColor {
    convenience init(hex: String) {
        var s = hex.replacingOccurrences(of: "#", with: "")
        if s.count == 3 {
            s = s.map { "\($0)\($0)" }.joined()
        }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        self.init(
            red:   CGFloat((v >> 16) & 0xFF) / 255.0,
            green: CGFloat((v >> 8)  & 0xFF) / 255.0,
            blue:  CGFloat(v & 0xFF) / 255.0,
            alpha: 1.0
        )
    }
}
