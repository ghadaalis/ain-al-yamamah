//
//  APIClient.swift
//  AinYamama
//
//  Created by Ghada Alshabanat on 21/06/1447 AH.
//

import UIKit

struct PredictResponse: Decodable {
    let plate_text: String?
    let is_reported: Bool
    let message: String
    let event_id: String?
}

final class APIClient {
    // حطي رابط Cloud Run لاحقًا
    static let baseURL = URL(string: "https://YOUR_CLOUD_RUN_URL/predict")!

    static func predict(image: UIImage, lat: Double?, lng: Double?, completion: @escaping (Result<PredictResponse, Error>) -> Void) {
        guard let jpeg = image.jpegData(compressionQuality: 0.9) else {
            completion(.failure(NSError(domain: "jpeg", code: -1)))
            return
        }

        var request = URLRequest(url: baseURL)
        request.httpMethod = "POST"

        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()

        func addField(_ name: String, _ value: String) {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
        }

        // lat/lng اختياريين
        if let lat { addField("lat", String(lat)) }
        if let lng { addField("lng", String(lng)) }

        // الصورة
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"image\"; filename=\"photo.jpg\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
        body.append(jpeg)
        body.append("\r\n".data(using: .utf8)!)

        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, _, err in
            if let err { return completion(.failure(err)) }
            guard let data else { return completion(.failure(NSError(domain: "noData", code: -2))) }

            do {
                let decoded = try JSONDecoder().decode(PredictResponse.self, from: data)
                completion(.success(decoded))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
}
